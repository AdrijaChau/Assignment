import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const getAuthHeader = () => ({
  headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
});

export const fetchExpenses = async () => {
  const response = await axios.get(`${API_URL}/expenses`, getAuthHeader());
  return response.data;
};

export const createExpenseApi = async (expenseData) => {
  const response = await axios.post(`${API_URL}/expenses`, expenseData, getAuthHeader());
  return response.data;
};

export const approveExpenseApi = async (id, status) => {
  const response = await axios.patch(`${API_URL}/expenses/${id}/approve`, { status }, getAuthHeader());
  return response.data;
};
