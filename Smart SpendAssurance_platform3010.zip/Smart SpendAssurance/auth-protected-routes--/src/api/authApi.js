import axios from "axios";
 
// Point this to your FastAPI backend URL (default is usually port 8000)
const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";
 
export const loginApi = async (credentials) => {
  try {
    const response = await axios.post(`${API_URL}/api/login`, credentials);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};
