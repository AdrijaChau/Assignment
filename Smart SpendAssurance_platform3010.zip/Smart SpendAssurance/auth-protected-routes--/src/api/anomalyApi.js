import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const getAuthHeader = () => ({
  headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
});

export const fetchAnomalies = async () => {
  const response = await axios.get(`${API_URL}/anomalies`, getAuthHeader());
  return response.data;
};
