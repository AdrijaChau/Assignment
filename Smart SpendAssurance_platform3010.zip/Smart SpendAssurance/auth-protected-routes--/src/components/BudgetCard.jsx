import React from 'react';

const BudgetCard = ({ budget }) => {
  const percentage = (budget.spent / budget.limit) * 100;
  const isOverrun = percentage >= 100;

  return (
    <div style={{ background: 'white', padding: '20px', borderRadius: '8px', marginBottom: '15px', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
        <strong>{budget.department} Division Budget</strong>
        <span style={{ color: isOverrun ? '#e74c3c' : '#27ae60' }}>
          {percentage.toFixed(1)}% Spent
        </span>
      </div>
      <div style={{ background: '#e0e0e0', height: '12px', borderRadius: '6px', overflow: 'hidden' }}>
        <div style={{ width: `${Math.min(percentage, 100)}%`, background: isOverrun ? '#e74c3c' : '#2ecc71', height: '100%' }}></div>
      </div>
      <div style={{ marginTop: '8px', fontSize: '0.9rem', color: '#7f8c8d' }}>
        Spent: ${budget.spent} / Limit: ${budget.limit}
      </div>
    </div>
  );
};

export default BudgetCard;
