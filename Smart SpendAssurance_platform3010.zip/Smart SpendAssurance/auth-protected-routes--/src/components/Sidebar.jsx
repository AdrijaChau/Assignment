import React from 'react';
import { Link } from 'react-router-dom';

const Sidebar = () => {
  return (
    <aside style={{ width: '220px', background: '#34495e', color: 'white', minHeight: 'calc(100vh - 70px)', padding: '1rem' }}>
      <ul style={{ listStyleType: 'none', padding: 0 }}>
        <li style={{ margin: '15px 0' }}><Link to="/" style={{ color: 'white', textDecoration: 'none' }}>📊 Dashboard</Link></li>
        <li style={{ margin: '15px 0' }}><Link to="/expenses" style={{ color: 'white', textDecoration: 'none' }}>💵 Expenses List</Link></li>
        <li style={{ margin: '15px 0' }}><Link to="/create-expense" style={{ color: 'white', textDecoration: 'none' }}>➕ Create Expense</Link></li>
        <li style={{ margin: '15px 0' }}><Link to="/approvals" style={{ color: 'white', textDecoration: 'none' }}>✅ Approvals</Link></li>
        <li style={{ margin: '15px 0' }}><Link to="/budgets" style={{ color: 'white', textDecoration: 'none' }}>🛡️ Budgets</Link></li>
        <li style={{ margin: '15px 0' }}><Link to="/analytics" style={{ color: 'white', textDecoration: 'none' }}>📈 Spending Trends</Link></li>
        <li style={{ margin: '15px 0' }}><Link to="/anomalies" style={{ color: 'white', textDecoration: 'none' }}>⚠️ AI Anomalies</Link></li>
      </ul>
    </aside>
  );
};

export default Sidebar;
