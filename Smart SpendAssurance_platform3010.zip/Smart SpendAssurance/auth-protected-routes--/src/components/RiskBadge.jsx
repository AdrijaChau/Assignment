import React from 'react';

const RiskBadge = ({ score }) => {
  let badgeColor = '#2ecc71'; // Low risk
  let text = 'Low Risk';

  if (score >= 75) {
    badgeColor = '#e74c3c'; // High risk / Fraudulent
    text = 'High Risk';
  } else if (score >= 40) {
    badgeColor = '#f39c12'; // Medium risk / Anomaly
    text = 'Medium Risk';
  }

  return (
    <span style={{ backgroundColor: badgeColor, color: 'white', padding: '4px 8px', borderRadius: '12px', fontSize: '0.8rem', fontWeight: 'bold' }}>
      {text} ({score}%)
    </span>
  );
};

export default RiskBadge;
