import React from 'react';

const DashboardCard = ({ title, value, color }) => {
  return (
    <div style={{ background: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', flex: 1, borderTop: `5px solid ${color || '#3498db'}` }}>
      <h4 style={{ margin: '0 0 10px 0', color: '#7f8c8d' }}>{title}</h4>
      <h2 style={{ margin: 0, color: '#2c3e50' }}>{value}</h2>
    </div>
  );
};

export default DashboardCard;
