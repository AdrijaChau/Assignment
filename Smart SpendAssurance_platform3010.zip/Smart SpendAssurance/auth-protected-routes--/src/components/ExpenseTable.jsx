import React from 'react';
import RiskBadge from './RiskBadge';

const ExpenseTable = ({ expenses, onAction, showActions = false }) => {
  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '15px', background: 'white' }}>
      <thead>
        <tr style={{ background: '#f2f2f2', textAlign: 'left' }}>
          <th style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>Employee</th>
          <th style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>Category</th>
          <th style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>Amount</th>
          <th style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>AI Risk Risk</th>
          <th style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>Status</th>
          {showActions && <th style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>Actions</th>}
        </tr>
      </thead>
      <tbody>
        {expenses.map((expense) => (
          <tr key={expense.id}>
            <td style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>{expense.employee}</td>
            <td style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>{expense.category}</td>
            <td style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>${expense.amount}</td>
            <td style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>
              <RiskBadge score={expense.riskScore} />
            </td>
            <td style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>{expense.status}</td>
            {showActions && (
              <td style={{ padding: '12px', borderBottom: '1px solid #ddd' }}>
                <button onClick={() => onAction(expense.id, 'Approved')} style={{ background: '#2ecc71', color: 'white', marginRight: '5px', border: 'none', padding: '5px 10px', cursor: 'pointer' }}>Approve</button>
                <button onClick={() => onAction(expense.id, 'Rejected')} style={{ background: '#e74c3c', color: 'white', border: 'none', padding: '5px 10px', cursor: 'pointer' }}>Reject</button>
              </td>
            )}
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default ExpenseTable;
