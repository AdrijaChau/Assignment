import React, { useEffect, useState } from 'react';
import ExpenseTable from '../components/ExpenseTable';

const Anomalies = () => {
  const [anomalies, setAnomalies] = useState([]);

  useEffect(() => {
    setAnomalies([
      { id: 2, employee: 'Bob Johnson', category: 'Software Subs', amount: 4500, riskScore: 82, status: 'Pending' },
      { id: 5, employee: 'Malicious Actor', category: 'Cash Advance', amount: 9999, riskScore: 97, status: 'Flagged' }
    ]);
  }, []);

  return (
    <div style={{ borderLeft: '4px solid #e74c3c', paddingLeft: '15px' }}>
      <h2 style={{ color: '#c0392b' }}>AI Anomaly & Potential Fraud Watchlist</h2>
      <p>High-risk items flagged for automated review due to uncharacteristic structural spend behavior.</p>
      <ExpenseTable expenses={anomalies} />
    </div>
  );
};

export default Anomalies;
