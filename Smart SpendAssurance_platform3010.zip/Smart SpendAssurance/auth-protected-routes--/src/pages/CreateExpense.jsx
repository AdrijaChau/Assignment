import React, { useState } from 'react';
import { createExpenseApi } from '../api/expenseApi';

const CreateExpense = () => {
  const [category, setCategory] = useState('');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setMessage('Submitting transaction token to AI verification pipeline...');
    
    setTimeout(() => {
      setMessage('Expense report generated and staged successfully inside ledger!');
      setCategory('');
      setAmount('');
      setDescription('');
    }, 1500);
  };

  return (
    <div style={{ maxWidth: '500px', background: 'white', padding: '25px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
      <h2>Submit New Reimbursement Claim</h2>
      {message && <div style={{ padding: '10px', background: '#e1f5fe', color: '#0288d1', marginBottom: '15px' }}>{message}</div>}
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '15px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Category</label>
          <select value={category} onChange={(e) => setCategory(e.target.value)} required style={{ width: '100%', padding: '8px' }}>
            <option value="">Select Category</option>
            <option value="Travel">Travel & Lodging</option>
            <option value="Meals">Client Entertainment & Meals</option>
            <option value="Software">Software & SaaS Subscriptions</option>
            <option value="Hardware">Hardware Procurement</option>
          </select>
        </div>
        <div style={{ marginBottom: '15px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Amount ($)</label>
          <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} required style={{ width: '100%', padding: '8px' }} />
        </div>
        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Business Justification</label>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows="4" required style={{ width: '100%', padding: '8px' }}></textarea>
        </div>
        <button type="submit" style={{ padding: '10px 20px', background: '#2ecc71', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
          Submit to Governance Audit
        </button>
      </form>
    </div>
  );
};

export default CreateExpense;
