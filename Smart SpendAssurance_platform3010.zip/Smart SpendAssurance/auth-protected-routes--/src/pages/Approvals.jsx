import React, { useState, useEffect } from 'react';
import ExpenseTable from '../components/ExpenseTable';

const Approvals = () => {
  const [pendingExpenses, setPendingExpenses] = useState([]);

  useEffect(() => {
    setPendingExpenses([
      { id: 2, employee: 'Bob Johnson', category: 'Software Subs', amount: 4500, riskScore: 82, status: 'Pending' },
      { id: 4, employee: 'Diana Prince', category: 'Hardware', amount: 3200, riskScore: 55, status: 'Pending' }
    ]);
  }, []);

  const handleApprovalAction = (id, newStatus) => {
    setPendingExpenses(prev => prev.filter(item => item.id !== id));
    alert(`Expense verification finalized as: ${newStatus}`);
  };

  return (
    <div>
      <h2>Manager Authorization Queue</h2>
      <p>Review items below flagged by the automated audit rules structure.</p>
      <ExpenseTable expenses={pendingExpenses} onAction={handleApprovalAction} showActions={true} />
    </div>
  );
};

export default Approvals;
