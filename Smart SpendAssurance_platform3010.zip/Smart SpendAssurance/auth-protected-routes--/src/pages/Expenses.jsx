import React, { useEffect, useState } from 'react';
import ExpenseTable from '../components/ExpenseTable';
import { fetchExpenses } from '../api/expenseApi';

const Expenses = () => {
  const [expenses, setExpenses] = useState([]);

  useEffect(() => {
    // Mocking active enterprise expense list
    setExpenses([
      { id: 1, employee: 'Alice Smith', category: 'Travel', amount: 1200, riskScore: 15, status: 'Approved' },
      { id: 2, employee: 'Bob Johnson', category: 'Software Subs', amount: 4500, riskScore: 82, status: 'Pending' },
      { id: 3, employee: 'Charlie Brown', category: 'Meals', amount: 150, riskScore: 45, status: 'Approved' },
    ]);
  }, []);

  return (
    <div>
      <h2>Enterprise Expense Tracking Logs</h2>
      <ExpenseTable expenses={expenses} />
    </div>
  );
};

export default Expenses;
