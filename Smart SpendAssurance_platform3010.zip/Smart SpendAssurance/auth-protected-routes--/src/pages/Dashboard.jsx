import React, { useEffect, useState } from 'react';
import DashboardCard from '../components/DashboardCard';
import ExpenseTable from '../components/ExpenseTable';

const Dashboard = () => {
  const [metrics, setMetrics] = useState({ totalExpenses: 0, pendingApprovals: 0, flagAnomalies: 0 });
  const [recentExpenses, setRecentExpenses] = useState([]);

  useEffect(() => {
    // Populate mock analytics dashboard metrics
    setMetrics({ totalExpenses: '$142,350', pendingApprovals: '18 Cases', flagAnomalies: '4 Flagged' });
    setRecentExpenses([
      { id: 1, employee: 'Alice Smith', category: 'Travel', amount: 1200, riskScore: 15, status: 'Approved' },
      { id: 2, employee: 'Bob Johnson', category: 'Software Subs', amount: 4500, riskScore: 82, status: 'Pending' },
    ]);
  }, []);

  return (
    <div>
      <h2 style={{ marginBottom: '20px' }}>Governance Dashboard Overview</h2>
      <div style={{ display: 'flex', gap: '20px', marginBottom: '30px' }}>
        <DashboardCard title="Total Monitored Spend" value={metrics.totalExpenses} color="#3498db" />
        <DashboardCard title="Awaiting Manager Review" value={metrics.pendingApprovals} color="#f39c12" />
        <DashboardCard title="AI Detected Anomalies" value={metrics.flagAnomalies} color="#e74c3c" />
      </div>
      <h3>Recent Compliance Log Activity</h3>
      <ExpenseTable expenses={recentExpenses} />
    </div>
  );
};

export default Dashboard;
