import React, { useState, useEffect } from 'react';
import BudgetCard from '../components/BudgetCard';

const Budgets = () => {
  const [budgets, setBudgets] = useState([]);

  useEffect(() => {
    setBudgets([
      { id: 1, department: 'Engineering', spent: 75000, limit: 100000 },
      { id: 2, department: 'Marketing', spent: 52000, limit: 50000 }, // Overrun predicted
      { id: 3, department: 'Sales', spent: 23000, limit: 60000 }
    ]);
  }, []);

  return (
    <div>
      <h2>Departmental Budgets Compliance Matrix</h2>
      <div style={{ marginTop: '20px' }}>
        {budgets.map(budget => (
          <BudgetCard key={budget.id} budget={budget} />
        ))}
      </div>
    </div>
  );
};

export default Budgets;
