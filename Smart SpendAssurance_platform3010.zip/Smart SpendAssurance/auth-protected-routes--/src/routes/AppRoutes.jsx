import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from '../pages/Dashboard';
import Expenses from '../pages/Expenses';
import CreateExpense from '../pages/CreateExpense';
import Approvals from '../pages/Approvals';
import Budgets from '../pages/Budgets';
import Analytics from '../pages/Analytics';
import Anomalies from '../pages/Anomalies';
import Login from '../pages/Login';
import Navbar from '../components/Navbar';
import Sidebar from '../components/Sidebar';

// High-level component to protect system route security tokens
const ProtectedLayout = ({ children }) => {
  const isAuthenticated = !!localStorage.getItem('token');
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <Navbar />
      <div style={{ display: 'flex', flex: 1 }}>
        <Sidebar />
        <main style={{ flex: 1, padding: '20px', background: '#f5f6fa', overflowY: 'auto' }}>
          {children}
        </main>
      </div>
    </div>
  );
};

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<ProtectedLayout><Dashboard /></ProtectedLayout>} />
      <Route path="/expenses" element={<ProtectedLayout><Expenses /></ProtectedLayout>} />
      <Route path="/create-expense" element={<ProtectedLayout><CreateExpense /></ProtectedLayout>} />
      <Route path="/approvals" element={<ProtectedLayout><Approvals /></ProtectedLayout>} />
      <Route path="/budgets" element={<ProtectedLayout><Budgets /></ProtectedLayout>} />
      <Route path="/analytics" element={<ProtectedLayout><Analytics /></ProtectedLayout>} />
      <Route path="/anomalies" element={<ProtectedLayout><Anomalies /></ProtectedLayout>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default AppRoutes;
