from fastapi import APIRouter
from fastapi import Depends
from sqlalchemy.orm import Session
from uuid import uuid4

from database import get_db
from models.expense import Expense
from schemas.expense_schema import ExpenseCreate

router = APIRouter(
    prefix="/expenses",
    tags=["Expenses"]
)

@router.get("/")
def get_expenses(
    db: Session = Depends(get_db)
):
    return db.query(Expense).all()


@router.post("/")
def create_expense(
    expense: ExpenseCreate,
    db: Session = Depends(get_db)
):

    new_expense = Expense(

        expense_id=uuid4(),

        employee_id=expense.employee_id,

        category_id=expense.category_id,

        amount=expense.amount,

        description=expense.description,

        status="Pending",

        risk_score=0

    )

    db.add(new_expense)

    db.commit()

    db.refresh(new_expense)

    return new_expense