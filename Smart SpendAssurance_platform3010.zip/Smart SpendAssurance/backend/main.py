from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import text
from routers.expense import router as expense_router

from database import get_db

app = FastAPI()

app.include_router(expense_router)

origins = [
    "http://localhost:5175",
    "http://127.0.0.1:5175",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {
        "message": "FastAPI backend is connected!"
    }

@app.get("/test-db")
def test_db(db: Session = Depends(get_db)):
    result = db.execute(
        text("SELECT current_database();")
    )

    return {
        "database": result.fetchone()[0]
    }