from sqlalchemy import Column
from sqlalchemy import Numeric
from sqlalchemy import Integer
from sqlalchemy import Text
from sqlalchemy import String

from sqlalchemy.dialects.postgresql import UUID

from database import Base


class Expense(Base):

    __tablename__ = "expenses"

    expense_id = Column(
        UUID(as_uuid=True),
        primary_key=True
    )

    employee_id = Column(
        UUID(as_uuid=True)
    )

    category_id = Column(
        UUID(as_uuid=True)
    )

    vendor_id = Column(
        UUID(as_uuid=True)
    )

    amount = Column(Numeric)

    description = Column(Text)

    status = Column(String)

    risk_score = Column(Integer)