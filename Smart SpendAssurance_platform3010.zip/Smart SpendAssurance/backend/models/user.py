from sqlalchemy import Column
from sqlalchemy import String
from sqlalchemy import Boolean

from database import Base

class User(Base):

    __tablename__ = "users"

    id = Column(
        String,
        primary_key=True
    )

    employee_id = Column(
        String,
        unique=True
    )

    first_name = Column(String)

    last_name = Column(String)

    email = Column(
        String,
        unique=True
    )

    password = Column(String)

    role = Column(String)

    is_active = Column(
        Boolean,
        default=True
    )