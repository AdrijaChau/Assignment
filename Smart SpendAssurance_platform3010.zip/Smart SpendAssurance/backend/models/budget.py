from sqlalchemy import Column
from sqlalchemy import String
from sqlalchemy import Numeric
from sqlalchemy import Integer

from database import Base

class Budget(Base):

    __tablename__ = "budgets"

    budget_id = Column(
        String,
        primary_key=True
    )

    department = Column(String)

    fiscal_year = Column(Integer)

    allocated_budget = Column(Numeric)

    utilized_budget = Column(Numeric)

    remaining_budget = Column(Numeric)