from sqlalchemy import Column
from sqlalchemy import String
from sqlalchemy import Text

from database import Base

class Anomaly(Base):

    __tablename__ = "anomalies"

    anomaly_id = Column(
        String,
        primary_key=True
    )

    expense_id = Column(String)

    anomaly_type = Column(String)

    severity = Column(String)

    status = Column(String)

    recommendation = Column(Text)