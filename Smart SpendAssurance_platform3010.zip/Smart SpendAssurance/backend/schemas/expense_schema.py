from pydantic import BaseModel
from uuid import UUID


class ExpenseCreate(BaseModel):

    employee_id: UUID

    category_id: UUID

    amount: float

    description: str