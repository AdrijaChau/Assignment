from pydantic import BaseModel

class AnomalyCreate(BaseModel):

    expense_id: str

    anomaly_type: str

    severity: str

    recommendation: str