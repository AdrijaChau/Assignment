from pydantic import BaseModel

class BudgetCreate(BaseModel):

    department: str

    fiscal_year: int

    allocated_budget: float