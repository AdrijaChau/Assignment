from pydantic import BaseModel

class UserCreate(BaseModel):

    employee_id: str
    first_name: str
    last_name: str
    email: str
    password: str
    role: str