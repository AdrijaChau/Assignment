 
import { useState } from "react";
import events from "../data/events";
import EventCard from "../components/EventCard";
import RegisterForm from "../components/RegisterForm";
import { useEvents } from "../context/EventContext";
 
function Events() {
 
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [selectedEvent, setSelectedEvent] = useState(null);
 
  const { addRegistration, getAvailableSeats } = useEvents();
 
  const filteredEvents = events.filter((event) => {
 
    const matchesSearch = event.title
      .toLowerCase()
      .includes(search.toLowerCase());
 
    const matchesCategory =
      category === "All" || event.category === category;
 
    return matchesSearch && matchesCategory;
  });
 
  const handleRegister = (event) => {
    setSelectedEvent(event);
  };
 
  const handleSubmit = (data) => {
 
    const result = addRegistration(data);
 
    alert(result.message);
 
    if (result.success) {
      setSelectedEvent(null);
    }
  };
 
  return (
    <div className="events-page">
 
      <h2>Explore Community Events</h2>
 
      <p>Discover and register for upcoming events.</p>
 
      <input
        type="text"
        placeholder="Search events..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
 
      <select
        value={category}
        onChange={(e) => setCategory(e.target.value)}
      >
        <option value="All">All Categories</option>
        <option value="Technology">Technology</option>
        <option value="Arts">Arts</option>
        <option value="Life Skills">Life Skills</option>
      </select>
 
      <div className="events-container">
 
        {filteredEvents.length > 0 ? (
 
          filteredEvents.map((event) => (
 
            <EventCard
              key={event.id}
              event={event}
              availableSeats={getAvailableSeats(event.id)}
              onRegister={handleRegister}
            />
 
          ))
 
        ) : (
 
          <p>No events found.</p>
 
        )}
 
      </div>
 
      {selectedEvent && (
 
        <RegisterForm
          event={selectedEvent}
          onSubmit={handleSubmit}
          onClose={() => setSelectedEvent(null)}
        />
 
      )}
 
    </div>
  );
}
 
export default Events;
 