 
import { createContext, useContext, useState, useEffect } from "react";
import events from "../data/events";
 
const EventContext = createContext();
 
export function EventProvider({ children }) {
 
  const [registrations, setRegistrations] = useState(() => {
    const saved = localStorage.getItem("registrations");
    return saved ? JSON.parse(saved) : [];
  });
 
  // Save registrations whenever they change
  useEffect(() => {
    localStorage.setItem(
      "registrations",
      JSON.stringify(registrations)
    );
  }, [registrations]);
 
  // Calculate available seats
  const getAvailableSeats = (eventId) => {
 
    const event = events.find((e) => e.id === eventId);
 
    if (!event) return 0;
 
    const registeredCount = registrations.filter(
      (r) => r.eventId === eventId
    ).length;
 
    return event.capacity - registeredCount;
  };
 
  // Register attendee
  const addRegistration = (data) => {
 
    const event = events.find(
      (e) => e.id === data.eventId
    );
 
    if (!event) {
      return { success: false, message: "Event not found" };
    }
 
    const duplicate = registrations.some(
      (r) =>
        r.eventId === data.eventId &&
        r.email.toLowerCase() === data.email.toLowerCase()
    );
 
    if (duplicate) {
      return {
        success: false,
        message: "You are already registered for this event"
      };
    }
 
    if (getAvailableSeats(data.eventId) <= 0) {
      return {
        success: false,
        message: "Sorry, this event is fully booked"
      };
    }
 
    const newRegistration = {
      id: Date.now(),
      ...data
    };
 
    setRegistrations((prev) => [
      ...prev,
      newRegistration
    ]);
 
    return {
      success: true,
      message: "Registration successful!"
    };
  };
 
  // Cancel registration
  const cancelRegistration = (id) => {
 
    setRegistrations((prev) =>
      prev.filter((r) => r.id !== id)
    );
 
  };
 
  return (
    <EventContext.Provider
      value={{
        registrations,
        addRegistration,
        cancelRegistration,
        getAvailableSeats
      }}
    >
      {children}
    </EventContext.Provider>
  );
}
 
// Custom hook
export function useEvents() {
  return useContext(EventContext);
}

 