import {Link} from "react-router-dom";
export default function Home(){
    return (
        <div className="container">
            <h1>Authentication Demo</h1>
            <p>Learn how React protects privte pages.</p>

            <nav>
                <Link to="/login">Login</Link>
                {"|"}
                <Link to="/dashboard">Open Dashboard</Link>
            </nav>
            
        </div>

    );

}